
var MID = "VqSJZP66509836763782";
var MKEY = "0RkFzm%V9PGG9yGo";

var ENV= 'securegw.paytm.in';
var WEBSITE= 'DEFAULT';

exports.MID = MID;
exports.MKEY = MKEY;
exports.ENV = ENV;
exports.WEBSITE = WEBSITE;