import { Component } from '@angular/core';

@Component({
  selector: 'app-third1',
  templateUrl: './third1.component.html',
  styleUrls: ['./third1.component.scss'],
})
export class Third1Component {
  constructor() {
    //constructor
  }
}
