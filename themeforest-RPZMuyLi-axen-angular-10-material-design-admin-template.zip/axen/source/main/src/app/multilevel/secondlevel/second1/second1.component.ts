import { Component } from '@angular/core';

@Component({
  selector: 'app-second1',
  templateUrl: './second1.component.html',
  styleUrls: ['./second1.component.scss'],
})
export class Second1Component {
  constructor() {
    //constructor
  }
}
