import { Component } from '@angular/core';

@Component({
  selector: 'app-second2',
  templateUrl: './second2.component.html',
  styleUrls: ['./second2.component.scss'],
})
export class Second2Component {
  constructor() {
    //constructor
  }
}
