
var MID = "JpimjC42653763117277";
var MKEY = "Zcn1cYy6WXq81CFv";

var ENV= 'securegw-stage.paytm.in';
var WEBSITE= 'WEBSTAGING';

exports.MID = MID;
exports.MKEY = MKEY;
exports.ENV = ENV;
exports.WEBSITE = WEBSITE;